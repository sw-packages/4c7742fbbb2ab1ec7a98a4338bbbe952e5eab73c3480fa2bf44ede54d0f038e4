/*
 * SObjectizer-5
 */

/*!
 * \file
 * \brief Top-level header file for all testing-related stuff.
 *
 * \since
 * v.5.5.24
 */

#pragma once

#include <so_5/experimental/testing/v1/all.hpp>

